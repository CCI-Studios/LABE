

Modernizr.addTest('mediaqueries', Modernizr.mq('only all'));