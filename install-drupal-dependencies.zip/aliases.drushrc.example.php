<?php
/*
$aliases['dev'] = array(
	'uri'=> 'dev.example.com',
	'root' => '/home/username/subdomains/dev/public_html',
	'remote-host'=> 'host.cciserver2.com',
	'remote-user'=> 'username',
	'path-aliases'=> array(
		'%files'=> 'sites/default/files',
	),
	'ssh-options'=> '-p 37241'
);
*/
